//! Shared utilities and types for dashboard components

pub mod types;
pub mod formatting;

